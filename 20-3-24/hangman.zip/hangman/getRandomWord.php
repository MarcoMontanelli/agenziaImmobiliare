<?php
// Path to the text file that contains words
$filePath = '1000_parole_italiane_comuni.txt';

// Reads the file into an array. Each line becomes an element in the array.
$words = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

// Checks if the words array is not empty
if (!empty($words)) {
    // Selects a random word
    $randomWord = $words[array_rand($words)];
    // Returns the random word
    echo $randomWord;
} else {
    echo "Errore file vuoto.";
}
?>