<?php
session_start(); // Starts the session or resume the existing one


$host = 'localhost';
$dbname = 'impiccato';
$user = 'root';
$pass = '';

// Creates database connection
$conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

// Fetches form data
$attempts = isset($_POST['infiniteAttempts']) ? NULL : $_POST['attempts']; // If infinite attempts are checked, sets attempts to NULL
$infiniteAttempts = isset($_POST['infiniteAttempts']) ? 1 : 0; // Converts checkbox presence to boolean
$wordToGuess = $_POST['wordToGuess']; // The word to guess, either randomly generated client-side or manually entered

// Retrieves the creator's ID from the session
$creatorId = $_SESSION['player_id'] ?? null; 

// If there is no player_id in the session, redirect to the login page
if (null === $creatorId) {
    header("Location: clientEnterName.php"); // Redirect to the login page
    exit;
}

try {
    // Starts a transaction
    $conn->beginTransaction();

    // Prepares SQL to insert the game
    $sql = "INSERT INTO hangman_game (creator_id, word_to_guess, is_game_active, attempts, infinite_attempts) VALUES (?, ?, 1, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$creatorId, $wordToGuess, $attempts, $infiniteAttempts]);

    // Retrieves the last insert id to generate a unique game code or use the ID itself as a code
    $gameId = $conn->lastInsertId();
    $code = uniqid(); // Generates a unique code

    // Updates the game with the unique code
    $sqlUpdate = "UPDATE hangman_game SET code = ? WHERE id = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->execute([$code, $gameId]);

    // Commits the transaction
    $conn->commit();

    // Saves the game ID and the player's role to the session
    $_SESSION['game_id'] = $gameId;
    $_SESSION['role'] = 'creator'; // The current user is the creator

    // Redirects to a new page to display the game code, passing the code via query string
    header("Location: displayGameCode.php?code=$code");
    exit();
} catch (PDOException $e) {
    
    $conn->rollBack();

    
    echo "Errore avvio gioco: " . $e->getMessage();
}