<?php
session_start(); 


$host = 'localhost';
$dbname = 'impiccato';
$user = 'root';
$pass = '';

// Creates a database connection
$conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

// Check if gameCode is set and not empty
if (isset($_POST['gameCode']) && !empty(trim($_POST['gameCode']))) {
    $gameCode = trim($_POST['gameCode']);

    // Prepare and execute query to find game by code
    $sql = "SELECT * FROM hangman_game WHERE code = :gameCode AND is_game_active = 1 LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':gameCode', $gameCode, PDO::PARAM_STR);
    $stmt->execute();

    $game = $stmt->fetch();
if ($game) {
    // Game exists and is active so we can connect to it 
    
    $_SESSION['game_id'] = $game['id'];
    
    // Determines if the player is the creator or guesser and directs him to the appropriate page
    $playerRole = ($game['creator_id'] == $_SESSION['player_id']) ? 'creator' : 'guesser';
    
    // Redirects to the appropriate game page
    $redirectUrl = ($playerRole == 'creator') ? 'creatorGamePage.php' : 'guesserGamePage.php';
    header("Location: $redirectUrl");
    exit;
} else {
    // Invalid game code or game is not active
    echo "Invalid game code or game is not active.";
    
}
}
?>

