<?php
session_start(); 


$host = 'localhost';
$dbname = 'impiccato';
$user = 'root';
$pass = '';

// Creates database connection
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];
$conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, $options);

// Checks if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);

    // Prepares SQL to insert the player
    $sql = "INSERT INTO player (username) VALUES (:username)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username);

    // Executes and check if successful
    if ($stmt->execute()) {
        // Retrieves the last insert ID (player ID)
        $playerId = $conn->lastInsertId();

        // Stores the player ID in the session
        $_SESSION['player_id'] = $playerId;

        // Redirects to the game selection page
        header("Location: gameSelectionPage.php");
        exit; // Stops the script
    } else {
        echo "Error registering player.";
    }
}

?>