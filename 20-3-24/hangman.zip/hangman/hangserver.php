<?php
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use hangman\application;

require __DIR__ . '\vendor\autoload.php';

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new application() // This is the class that will handle the WebSocket connections
        )
    ),
    8080 // Port number
);

$server->run();
?>