<?php
$code = $_GET['code'] ?? 'Errore nessun codice.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Game Code | SMONTABLOG</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#1a1a3e] flex justify-center items-center h-screen">
    <div class="text-white">
        <h1 class="text-3xl font-bold">IL TUO CODICE PARTITA:</h1>
        <p class="text-xl mt-4"><?php echo htmlspecialchars($code); ?></p>
    </div>
</body>
</html>